const botao11 = document.querySelector("main :nth-child(1)")
const botao21 = document.querySelector("main :nth-child(2)")
const botao31 = document.querySelector("main :nth-child(3)")

const botao12 = document.querySelector("main :nth-child(4)")
const botao22 = document.querySelector("main :nth-child(5)")
const botao32 = document.querySelector("main :nth-child(6)")

const botao13 = document.querySelector("main :nth-child(7)")
const botao23 = document.querySelector("main :nth-child(8)")
const botao33 = document.querySelector("main :nth-child(9)")

let turn = 0
const ox = ['O', 'X']

botao11.onclick = function() {
    if (botao11.textContent.trim() != '') return
    botao11.textContent = ox[turn % 2]
    turn++
}
botao21.onclick = function() {
    if (botao21.textContent.trim() != '') return
    botao21.textContent = ox[turn % 2]
    turn++
}
botao31.onclick = function() {
    if (botao31.textContent.trim() != '') return
    botao31.textContent = ox[turn % 2]
    turn++
}